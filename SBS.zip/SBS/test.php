<?php
echo "Hello World!";
?> 